<nav>
<h1>Menu</h1>
<ul>
    <li><a href="home.php">Home</a>
    <li><a href="eventsrange.php">View Events By Range of Dates</a>
    <li><a href="manageevents.php">Manage Events</a>
    <li><a href="invitations.php">View Pending Invitations</a>
    <li><a href="friendschedule.php">View Friend's Schedule</a>
    <li><a href="create.php">Create Event</a>
</ul>
</nav>
